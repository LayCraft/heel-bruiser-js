# Battlesnake engine

navigate to this directory on your local machine and activete the engine with `./engine dev`.

Open a browser and go to http://localhost:3010/

This will give you a web based environment to test a snake locally.

Instructions:

http://docs.battlesnake.io/zero-to-snake-macos.html